package com.myprivateai.app

import android.content.ContentValues
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Base64
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { PrivateAIApp() } }
    }

    private fun savePng(bytes: ByteArray): Boolean {
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "MyPrivateAI_${UUID.randomUUID()}.png")
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/MyPrivateAI")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: return false
        contentResolver.openOutputStream(uri)?.use { it.write(bytes) } ?: return false
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val done = ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }
            contentResolver.update(uri, done, null, null)
        }
        return true
    }

    @Composable
    private fun PrivateAIApp() {
        // Set these to your own private backend address and matching backend API_TOKEN.
        // Emulator: http://10.0.2.2:8000/
        // Real phone: http://YOUR_COMPUTER_LAN_IP:8000/
        val baseUrl = remember { mutableStateOf("http://10.0.2.2:8000/") }
        val token = remember { mutableStateOf("change_this_to_a_long_random_secret") }

        var pin by remember { mutableStateOf("") }
        var pinConfirm by remember { mutableStateOf("") }
        var unlocked by remember { mutableStateOf(false) }
        var prompt by remember { mutableStateOf("") }
        var mode by remember { mutableStateOf("generate") }
        var size by remember { mutableStateOf("1024x1024") }
        var sourceUri by remember { mutableStateOf<Uri?>(null) }
        var resultBytes by remember { mutableStateOf<ByteArray?>(null) }
        var busy by remember { mutableStateOf(false) }
        var status by remember { mutableStateOf("សូមកំណត់ backend URL និង PIN ដើម្បីចាប់ផ្ដើម។") }
        val scope = rememberCoroutineScope()
        val prefs = getSharedPreferences("private_ai_prefs", MODE_PRIVATE)
        val storedPin = remember { prefs.getString("pin", null) }

        val picker = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.GetContent()
        ) { uri -> sourceUri = uri }

        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)
        ) {
            Text("My Private AI", style = MaterialTheme.typography.headlineLarge)
            Text("កម្មវិធី AI បង្កើត និងកែរូបភាពផ្ទាល់ខ្លួន")
            Spacer(Modifier.height(16.dp))

            if (!unlocked) {
                Text(
                    if (storedPin == null) "បង្កើត PIN ថ្មី (ចងចាំ PIN នេះ)" else "បញ្ចូល PIN ដើម្បីបើកកម្មវិធី",
                    style = MaterialTheme.typography.titleMedium
                )
                OutlinedTextField(pin, { pin = it }, label = { Text("PIN") })
                if (storedPin == null) {
                    OutlinedTextField(pinConfirm, { pinConfirm = it }, label = { Text("បញ្ចូល PIN ម្ដងទៀត") })
                }
                Button(onClick = {
                    if (pin.length < 4) status = "PIN ត្រូវមានយ៉ាងតិច 4 ខ្ទង់"
                    else if (storedPin == null && pin != pinConfirm) status = "PIN មិនត្រូវគ្នា"
                    else if (storedPin == null) {
                        prefs.edit().putString("pin", pin).apply()
                        unlocked = true
                        status = "បានបើកកម្មវិធី"
                    } else if (pin == storedPin) {
                        unlocked = true
                        status = "បានបើកកម្មវិធី"
                    } else status = "PIN មិនត្រឹមត្រូវ"
                }, modifier = Modifier.fillMaxWidth()) { Text("បើកកម្មវិធី") }
                Text(status)
                return@Column
            }

            Text("Backend URL")
            OutlinedTextField(
                value = baseUrl.value,
                onValueChange = { baseUrl.value = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            Text("Access token (ត្រូវដូច API_TOKEN ក្នុង backend)")
            OutlinedTextField(
                value = token.value,
                onValueChange = { token.value = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = mode == "generate", onClick = { mode = "generate" }, label = { Text("រូបថ្មី") })
                FilterChip(selected = mode == "edit", onClick = { mode = "edit" }, label = { Text("កែរូប") })
            }

            OutlinedTextField(
                value = prompt,
                onValueChange = { prompt = it },
                label = { Text("ពិពណ៌នារូបភាព") },
                placeholder = { Text("ឧ. គូស្វាមីភរិយាខ្មែរ នៅប្រាសាទអង្គរវត្ត...") },
                modifier = Modifier.fillMaxWidth().height(140.dp)
            )

            if (mode == "generate") {
                Text("ទំហំរូប")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("1024x1024", "1536x1024", "1024x1536").forEach {
                        FilterChip(selected = size == it, onClick = { size = it }, label = { Text(it) })
                    }
                }
            } else {
                Button(onClick = { picker.launch("image/*") }, modifier = Modifier.fillMaxWidth()) {
                    Text("ជ្រើសរូបថតពី Gallery")
                }
                sourceUri?.let { AsyncImage(model = it, contentDescription = "រូបដើម", modifier = Modifier.fillMaxWidth().heightIn(max = 260.dp)) }
            }

            Spacer(Modifier.height(12.dp))
            Button(
                enabled = !busy && prompt.isNotBlank() && (mode == "generate" || sourceUri != null),
                onClick = {
                    busy = true
                    status = "កំពុងដំណើរការ..."
                    resultBytes = null
                    scope.launch {
                        try {
                            val output = withContext(Dispatchers.IO) {
                                if (mode == "generate") {
                                    postGenerate(baseUrl.value, token.value, prompt, size)
                                } else {
                                    val input = contentResolver.openInputStream(sourceUri!!)?.use { it.readBytes() }
                                        ?: error("មិនអាចអានរូបដើមបាន")
                                    postEdit(baseUrl.value, token.value, prompt, input, "image.jpg")
                                }
                            }
                            resultBytes = output
                            status = "បានបង្កើតរូបភាព! ចុចរក្សាទុកដើម្បីដាក់ក្នុង Gallery។"
                        } catch (e: Exception) {
                            status = "មានបញ្ហា៖ ${e.message ?: "មិនស្គាល់កំហុស"}"
                        } finally { busy = false }
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (busy) "កំពុងដំណើរការ..." else "✨ បង្កើត / កែរូបភាព") }

            Spacer(Modifier.height(12.dp))
            resultBytes?.let { bytes ->
                val bitmap = remember(bytes) { BitmapFactory.decodeByteArray(bytes, 0, bytes.size) }
                bitmap?.let {
                    Image(bitmap = it.asImageBitmap(), contentDescription = "AI result", modifier = Modifier.fillMaxWidth().heightIn(max = 480.dp))
                }
                Button(onClick = {
                    scope.launch {
                        val ok = withContext(Dispatchers.IO) { savePng(bytes) }
                        status = if (ok) "បានរក្សាទុកក្នុង Pictures/MyPrivateAI" else "រក្សាទុកមិនបាន"
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text("💾 រក្សាទុកទៅ Gallery") }
            }
            Spacer(Modifier.height(10.dp))
            Text(status)
            Spacer(Modifier.height(12.dp))
            Text(
                "ឯកជនភាព៖ រូបដែលអ្នកផ្ញើសម្រាប់កែ ត្រូវបានបញ្ជូនទៅ backend និងអ្នកផ្តល់ AI។ " +
                    "PIN នេះជាការការពារមូលដ្ឋានលើ app ប៉ុណ្ណោះ មិនមែនការអ៊ិនគ្រីបឯកសារទាំងមូលទេ។",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }

    private fun postGenerate(base: String, token: String, prompt: String, size: String): ByteArray {
        val boundary = "----MyPrivateAI${UUID.randomUUID()}"
        val conn = URL(base.trimEnd('/') + "/generate").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 30000
        conn.readTimeout = 180000
        conn.doOutput = true
        conn.setRequestProperty("Authorization", "Bearer $token")
        conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
        conn.outputStream.use { out ->
            writeField(out, boundary, "prompt", prompt)
            writeField(out, boundary, "size", size)
            out.write("--$boundary--\r\n".toByteArray())
        }
        return readImageResponse(conn)
    }

    private fun postEdit(base: String, token: String, prompt: String, image: ByteArray, filename: String): ByteArray {
        val boundary = "----MyPrivateAI${UUID.randomUUID()}"
        val conn = URL(base.trimEnd('/') + "/edit").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 30000
        conn.readTimeout = 180000
        conn.doOutput = true
        conn.setRequestProperty("Authorization", "Bearer $token")
        conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
        conn.outputStream.use { out ->
            writeField(out, boundary, "prompt", prompt)
            out.write("--$boundary\r\n".toByteArray())
            out.write("Content-Disposition: form-data; name=\"image\"; filename=\"$filename\"\r\n".toByteArray())
            out.write("Content-Type: image/jpeg\r\n\r\n".toByteArray())
            out.write(image)
            out.write("\r\n--$boundary--\r\n".toByteArray())
        }
        return readImageResponse(conn)
    }

    private fun writeField(out: java.io.OutputStream, boundary: String, name: String, value: String) {
        out.write("--$boundary\r\n".toByteArray())
        out.write("Content-Disposition: form-data; name=\"$name\"\r\n\r\n".toByteArray())
        out.write(value.toByteArray(Charsets.UTF_8))
        out.write("\r\n".toByteArray())
    }

    private fun readImageResponse(conn: HttpURLConnection): ByteArray {
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val body = stream?.bufferedReader()?.use { it.readText() } ?: ""
        conn.disconnect()
        if (code !in 200..299) {
            val message = try { JSONObject(body).optString("detail", "HTTP $code") } catch (_: Exception) { "HTTP $code" }
            error(message)
        }
        val b64 = JSONObject(body).getString("image_base64")
        return Base64.decode(b64, Base64.DEFAULT)
    }
}
